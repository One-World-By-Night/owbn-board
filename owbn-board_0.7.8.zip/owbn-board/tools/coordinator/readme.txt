=== <Tool Name> Module ===
Contributors: greghacke
Tags: owbn, coordinator, module, <toolname>
Requires at least: 6.0
Tested up to: 6.5
Requires PHP: 7.4
Version: 0.1.0
Stable tag: 0.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

The <Tool Name> module is part of the OWBN Coordinator Toolkit plugin. This module handles <brief description of responsibility>.

This module declares its master site (if applicable), registers post types, handles admin UI, and may respond to or dispatch webhooks.

== Changelog ==

= 0.1.0 =
* Initial scaffolding for the <Tool Name> module.