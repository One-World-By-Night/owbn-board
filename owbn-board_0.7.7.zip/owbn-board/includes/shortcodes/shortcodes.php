<?php

// File: includes/shortcodes/shortcodes.php
// @version 0.7.5
// @author greghacke

defined( 'ABSPATH' ) || exit;