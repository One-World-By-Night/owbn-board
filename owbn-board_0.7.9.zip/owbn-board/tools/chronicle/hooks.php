<?php

// File: tools/chronicle/hooks.php
// @version 1.6.1
// @author greghacke
// @tool chronicle

defined( 'ABSPATH' ) || exit;

