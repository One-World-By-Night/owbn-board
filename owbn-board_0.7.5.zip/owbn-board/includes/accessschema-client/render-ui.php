<?php

// File: accessschema-client/render-ui.php
// @version 0.7.5
// @author greghacke
// @tool accessschema-client

defined( 'ABSPATH' ) || exit;

