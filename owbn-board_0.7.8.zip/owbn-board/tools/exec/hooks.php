<?php

// File: tools/Exec/hooks.php
// @version 0.7.5
// @author greghacke
// @tool Exec

defined( 'ABSPATH' ) || exit;

