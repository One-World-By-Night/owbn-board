<?php

// File: tools/chronicle/shortcode.php
// @version 0.7.5
// @author greghacke
// @tool chronicle

defined( 'ABSPATH' ) || exit;

