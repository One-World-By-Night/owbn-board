<?php
/**
 * Events tile + [owbn_events] shortcode. Shortcode works on public pages.
 */

defined( 'ABSPATH' ) || exit;

function owbn_board_events_register_tile() {
	owbn_board_register_tile( [
		'id'         => 'board:events',
		'title'      => __( 'Upcoming Events', 'owbn-board' ),
		'icon'       => 'dashicons-megaphone',
		'read_roles' => [], // visible to all authenticated users
		'size'       => '2x2',
		'category'   => 'communication',
		'priority'   => 15,
		'poll_interval' => 15000,
		'render'     => 'owbn_board_render_events_tile',
	] );
}

function owbn_board_render_events_tile( $tile, $user_id, $can_write ) {
	echo owbn_board_events_render_list( [
		'limit'     => 6,
		'show_rsvp' => true,
		'show_cta'  => true,
	] );
}

/**
 * Register the [owbn_events] shortcode.
 */
function owbn_board_events_register_shortcode() {
	add_shortcode( 'owbn_events', 'owbn_board_events_shortcode_handler' );
}

// [owbn_events limit=6 id=N host="chronicle/mckn" show_rsvp=1 show_cta=0]
function owbn_board_events_shortcode_handler( $atts ) {
	$atts = shortcode_atts(
		[
			'limit'     => 6,
			'id'        => 0,
			'host'      => '',
			'show_rsvp' => true,
			'show_cta'  => false,
		],
		$atts,
		'owbn_events'
	);

	if ( function_exists( 'owbn_board_enqueue_assets' ) ) {
		owbn_board_enqueue_assets();
	}

	return owbn_board_events_render_list( [
		'limit'     => (int) $atts['limit'],
		'event_id'  => (int) $atts['id'],
		'host'      => sanitize_text_field( $atts['host'] ),
		'show_rsvp' => filter_var( $atts['show_rsvp'], FILTER_VALIDATE_BOOLEAN ),
		'show_cta'  => filter_var( $atts['show_cta'], FILTER_VALIDATE_BOOLEAN ),
	] );
}

// Shared renderer for tile and shortcode. Args: limit, event_id, host, show_rsvp, show_cta.
function owbn_board_events_render_list( array $args = [] ) {
	$args = wp_parse_args( $args, [
		'limit'     => 6,
		'event_id'  => 0,
		'host'      => '',
		'show_rsvp' => true,
		'show_cta'  => false,
	] );

	if ( ! function_exists( 'owc_events_get_upcoming' ) ) {
		return '<p class="owbn-board-events__empty">' . esc_html__( 'Events data unavailable.', 'owbn-board' ) . '</p>';
	}

	if ( $args['event_id'] ) {
		$single = owc_events_get_event( (int) $args['event_id'] );
		$events = ( $single && 'publish' === ( $single['status'] ?? '' ) ) ? [ $single ] : [];
	} elseif ( ! empty( $args['host'] ) ) {
		$events = owc_events_get_upcoming_for_host( $args['host'], (int) $args['limit'] );
	} else {
		$events = owc_events_get_upcoming( (int) $args['limit'] );
	}

	$user_id   = get_current_user_id();
	$is_host   = ( 'chronicles' === owbn_board_get_site_slug() );
	$is_admin  = $user_id && owbn_board_events_user_can_create( $user_id );
	$create_url = $is_host
		? admin_url( 'post-new.php?post_type=owbn_event' )
		: owbn_board_tool_url( 'chronicles', '/wp-admin/post-new.php?post_type=owbn_event' );

	ob_start();

	if ( empty( $events ) ) {
		echo '<p class="owbn-board-events__empty">' . esc_html__( 'No upcoming events.', 'owbn-board' ) . '</p>';
		if ( $args['show_cta'] && $is_admin ) {
			echo '<p class="owbn-board-events__manage"><a href="' . esc_url( $create_url ) . '"' . ( $is_host ? '' : ' target="_blank" rel="noopener"' ) . '>' . esc_html__( 'Create an event →', 'owbn-board' ) . '</a></p>';
		}
		return ob_get_clean();
	}
	?>
	<ul class="owbn-board-events">
		<?php foreach ( $events as $event ) :
			$event_id   = (int) ( $event['id'] ?? 0 );
			$title      = (string) ( $event['title'] ?? '' );
			$permalink  = (string) ( $event['permalink'] ?? '' );
			$tagline    = (string) ( $event['tagline'] ?? '' );
			$location   = (string) ( $event['location'] ?? '' );
			$start_dt   = (string) ( $event['start_dt'] ?? '' );
			$start      = $start_dt ? strtotime( $start_dt . ' UTC' ) : 0;
			$banner     = (string) ( $event['banner_url'] ?? '' );
			$rsvp       = ( $user_id && function_exists( 'owc_events_rsvp_get' ) ) ? owc_events_rsvp_get( $event_id, $user_id ) : null;
			?>
			<li class="owbn-board-events__item" data-event-id="<?php echo $event_id; ?>">
				<?php if ( $banner ) : ?>
					<img class="owbn-board-events__banner" src="<?php echo esc_url( $banner ); ?>" alt="" />
				<?php endif; ?>
				<div class="owbn-board-events__body">
					<a class="owbn-board-events__title" href="<?php echo esc_url( $permalink ); ?>"<?php echo $is_host ? '' : ' target="_blank" rel="noopener"'; ?>>
						<strong><?php echo esc_html( $title ); ?></strong>
					</a>
					<?php if ( '' !== $tagline ) : ?>
						<div class="owbn-board-events__tagline"><?php echo esc_html( $tagline ); ?></div>
					<?php endif; ?>
					<div class="owbn-board-events__meta">
						<?php if ( $start ) : ?>
							<span class="owbn-board-events__date" data-start="<?php echo (int) $start; ?>">
								<?php echo esc_html( wp_date( get_option( 'date_format' ), $start ) ); ?>
							</span>
						<?php endif; ?>
						<?php if ( '' !== $location ) : ?>
							<span class="owbn-board-events__location"><?php echo esc_html( $location ); ?></span>
						<?php endif; ?>
					</div>

					<?php if ( $args['show_rsvp'] ) : ?>
						<?php if ( $user_id ) : ?>
							<div class="owbn-board-events__rsvp" data-event-id="<?php echo $event_id; ?>">
								<button type="button" class="button button-small owbn-board-events__rsvp-btn<?php echo 'interested' === $rsvp ? ' is-active' : ''; ?>" data-status="interested">
									<?php esc_html_e( 'Interested', 'owbn-board' ); ?>
								</button>
								<button type="button" class="button button-small owbn-board-events__rsvp-btn<?php echo 'going' === $rsvp ? ' is-active' : ''; ?>" data-status="going">
									<?php esc_html_e( 'Going', 'owbn-board' ); ?>
								</button>
							</div>
						<?php else : ?>
							<div class="owbn-board-events__rsvp owbn-board-events__rsvp--login">
								<a href="<?php echo esc_url( wp_login_url( $permalink ) ); ?>" class="button button-small">
									<?php esc_html_e( 'Log in to RSVP', 'owbn-board' ); ?>
								</a>
							</div>
						<?php endif; ?>
					<?php endif; ?>
				</div>
			</li>
		<?php endforeach; ?>
	</ul>
	<?php if ( $args['show_cta'] && $is_admin ) : ?>
		<p class="owbn-board-events__manage">
			<a href="<?php echo esc_url( $create_url ); ?>"<?php echo $is_host ? '' : ' target="_blank" rel="noopener"'; ?>><?php esc_html_e( 'Create an event →', 'owbn-board' ); ?></a>
		</p>
	<?php endif;
	return ob_get_clean();
}
