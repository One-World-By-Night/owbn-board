<?php

// File: includes/utils/utilities.php
// @version 1.6.1
// @author greghacke

defined( 'ABSPATH' ) || exit;