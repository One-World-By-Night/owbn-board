<?php

// File: tools/chronicle/webhook.php
// @version 0.7.5
// @author greghacke
// @tool chronicle

defined( 'ABSPATH' ) || exit;

