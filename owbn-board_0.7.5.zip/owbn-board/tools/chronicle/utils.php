<?php

// File: tools/chronicle/utils.php
// @version 0.7.5
// @author greghacke
// @tool chronicle