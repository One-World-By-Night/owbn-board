<?php
// File: accessschema-client/hooks.php
// @version 1.6.1
// @tool accessschema-client

defined('ABSPATH') || exit;

if (!defined('AS_CLIENT_PREFIX')) {
    wp_die('AS_CLIENT_PREFIX not defined for AccessSchema Client.');
}

function as_client_option_key($key) {
    return AS_CLIENT_PREFIX . '_accessschema_' . $key;
}

/* Check if AccessSchema is in remote mode. */
function accessSchema_is_remote_mode() {
    return get_option(as_client_option_key('mode'), 'remote') === 'remote';
}

/* Get the stored remote AccessSchema URL. */
function accessSchema_client_get_remote_url() {
    $url = trim(get_option(as_client_option_key('client_url')));
    return rtrim($url, '/');
}

/* Get the stored remote AccessSchema API key. */
function accessSchema_client_get_remote_key() {
    return trim(get_option(as_client_option_key('client_key')));
}


/* Send a POST request to the accessSchema API endpoint.
 *
 * @param string $endpoint The API endpoint path (e.g., 'roles', 'grant', 'revoke').
 * @param array $body JSON body parameters.
 * @return array|WP_Error Response array or error.
 */
function accessSchema_client_remote_post($endpoint, array $body) {
    $url_base = accessSchema_client_get_remote_url();
    $key      = accessSchema_client_get_remote_key();

    if (!$url_base || !$key) {
        return new WP_Error('config_error', 'Remote URL or API key is not set.');
    }

    $url = trailingslashit($url_base) . ltrim($endpoint, '/');

    $response = wp_remote_post($url, [
        'headers' => [
            'Content-Type' => 'application/json',
            'x-api-key'    => $key,
        ],
        'body'    => wp_json_encode($body),
        'timeout' => 10,
    ]);

    if (is_wp_error($response)) {
        return $response;
    }

    $status = wp_remote_retrieve_response_code($response);
    $data   = json_decode(wp_remote_retrieve_body($response), true);

    if ($status !== 200 && $status !== 201) {
        return new WP_Error('api_error', 'Remote API returned HTTP ' . $status, $data);
    }

    return $data;
}

/* * Get remote roles for a user by email (with caching).
 */
function accessSchema_client_remote_get_roles_by_email($email) {
    $user = get_user_by('email', $email);

    if (!accessSchema_is_remote_mode()) {
        if (!$user) {
            return new WP_Error('user_not_found', 'User not found.', ['status' => 404]);
        }

        $response = accessSchema_client_local_post('roles', [
            'email' => sanitize_email($email),
        ]);

        return $response;
    }

    // REMOTE MODE – check cache first
    if ($user) {
        $cached = get_user_meta($user->ID, 'accessschema_cached_roles', true);
        if (!empty($cached) && is_array($cached)) {
            return ['roles' => $cached];
        }
    }

    // Fall back to external API
    $response = accessSchema_client_remote_post('roles', [
        'email' => sanitize_email($email),
    ]);

    if (!is_wp_error($response) && isset($response['roles']) && $user) {
        update_user_meta($user->ID, 'accessschema_cached_roles', $response['roles']);
        update_user_meta($user->ID, 'accessschema_cached_roles_timestamp', time());
    }

    return $response;
}

/* Grant a role to a user on the remote system.
 */
function accessSchema_client_remote_grant_role($email, $role_path) {
    $user = get_user_by('email', $email);

    $payload = [
        'email'     => sanitize_email($email),
        'role_path' => sanitize_text_field($role_path),
    ];

    if (!accessSchema_is_remote_mode()) {
        $result = accessSchema_client_local_post('grant', $payload);
    } else {
        $result = accessSchema_client_remote_post('grant', $payload);
    }

    // Invalidate cache in both modes
    if ($user) {
        delete_user_meta($user->ID, 'accessschema_cached_roles');
        delete_user_meta($user->ID, 'accessschema_cached_roles_timestamp');
    }

    return $result;
}

/* Revoke a role to a user on the remote system.
 */
function accessSchema_client_remote_revoke_role($email, $role_path) {
    $user = get_user_by('email', $email);

    $payload = [
        'email'     => sanitize_email($email),
        'role_path' => sanitize_text_field($role_path),
    ];

    if (!accessSchema_is_remote_mode()) {
        $result = accessSchema_client_local_post('revoke', $payload);
    } else {
        $result = accessSchema_client_remote_post('revoke', $payload);
    }

    // Invalidate cache in both modes
    if ($user) {
        delete_user_meta($user->ID, 'accessschema_cached_roles');
        delete_user_meta($user->ID, 'accessschema_cached_roles_timestamp');
    }

    return $result;
}
/* Refresh roles for a user by fetching from remote.
 *
 * @param WP_User $user The user object.
 * @return array|WP_Error The roles array or error.
 */
function accessSchema_refresh_roles_for_user($user) {
    if ($user instanceof WP_User) {
        $email = $user->user_email;

        // This call routes to remote or local depending on mode
        $roles = accessSchema_client_get_roles_by_email($email);

        if (!is_wp_error($roles) && isset($roles['roles'])) {
            update_user_meta($user->ID, 'accessschema_cached_roles', $roles['roles']);
            update_user_meta($user->ID, 'accessschema_cached_roles_timestamp', time());
            return $roles;
        }
    }

    return new WP_Error('refresh_failed', 'Could not refresh roles.');
}

/* Check if user has role or descendant.
 */
function accessSchema_client_remote_check_access($email, $role_path, $include_children = true) {
    $payload = [
        'email'            => sanitize_email($email),
        'role_path'        => sanitize_text_field($role_path),
        'include_children' => $include_children,
    ];

    if (!accessSchema_is_remote_mode()) {
        $data = accessSchema_client_local_post('check', $payload);
    } else {
        $data = accessSchema_client_remote_post('check', $payload);
    }

    if (is_wp_error($data)) {
        return $data;
    }

    return !empty($data['granted']);
}

/* Local API endpoint handler for client-side requests.
 *
 * @param string $endpoint The endpoint to call (e.g., 'roles', 'grant', 'revoke', 'check').
 * @param array $body The request body parameters.
 * @return array|WP_Error The response data or error.
 */
function accessSchema_client_local_post($endpoint, array $body) {
    $request = new WP_REST_Request('POST', '/access-schema/v1/' . ltrim($endpoint, '/'));
    $request->set_body_params($body);

    $function_map = [
        'roles'  => 'accessSchema_api_get_roles',
        'grant'  => 'accessSchema_api_grant_role',
        'revoke' => 'accessSchema_api_revoke_role',
        'check'  => 'accessSchema_api_check_permission',
    ];

    if (!isset($function_map[$endpoint])) {
        return new WP_Error('invalid_local_endpoint', 'Unrecognized local endpoint.');
    }

    $response = call_user_func($function_map[$endpoint], $request);

    if ($response instanceof WP_Error) {
        return $response;
    }

    return $response->get_data();
}

do_action('accessSchema_client_ready');