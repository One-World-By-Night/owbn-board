<?php

// File: includes/shortcodes/shortcodes.php
// @version 1.6.1
// @author greghacke

defined( 'ABSPATH' ) || exit;