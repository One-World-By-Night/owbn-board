<?php

// File: tools/chronicle/webhook.php
// @version 1.6.1
// @author greghacke
// @tool chronicle

defined( 'ABSPATH' ) || exit;

