<?php
// File: includes/render/init.php
// @version 0.7.5
// Author: greghacke

// File: includes/render/init.php

defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/render-admin.php';
require_once __DIR__ . '/render-ui.php';