<?php
// File: accessschema-client/fields.php
// @version 1.6.0
// @tool accessschema-client

defined('ABSPATH') || exit;

add_action('admin_init', function () {
    // Always register the settings (regardless of mode)
    register_setting('accessschema_client', 'accessschema_mode');
    register_setting('accessschema_client', 'accessschema_client_url', [
        'sanitize_callback' => 'esc_url_raw',
    ]);
    register_setting('accessschema_client', 'accessschema_client_key', [
        'sanitize_callback' => 'sanitize_text_field',
    ]);

    // Section: Mode selector
    add_settings_section(
        'accessschema_mode_section',
        'AccessSchema Client Mode',
        '__return_null',
        'accessschema-client'
    );

    add_settings_field(
        'accessschema_mode',
        'Connection Mode',
        function () {
            $mode = get_option('accessschema_mode', 'remote');
            ?>
            <label style="margin-right: 1rem;">
                <input type="radio" name="accessschema_mode" value="remote" <?php checked($mode, 'remote'); ?> />
                Remote
            </label>
            <label>
                <input type="radio" name="accessschema_mode" value="local" <?php checked($mode, 'local'); ?> />
                Local
            </label>
            <?php
        },
        'accessschema-client',
        'accessschema_mode_section'
    );

    // Section: Remote config fields (always registered, conditionally shown)
    add_settings_section(
        'accessschema_client_section',
        'Remote API Settings',
        '__return_null',
        'accessschema-client'
    );

    add_settings_field(
        'accessschema_client_url',
        'Remote AccessSchema URL',
        function () {
            $mode = get_option('accessschema_mode', 'remote');
            $val  = esc_url(get_option('accessschema_client_url'));
            $style = $mode === 'remote' ? '' : 'style="display:none"';

            echo "<div $style><input type='url' name='accessschema_client_url' value='" . esc_attr($val) . "' class='regular-text' /></div>";
        },
        'accessschema-client',
        'accessschema_client_section'
    );

    add_settings_field(
        'accessschema_client_key',
        'Remote API Key',
        function () {
            $mode = get_option('accessschema_mode', 'remote');
            $val  = get_option('accessschema_client_key');
            $style = $mode === 'remote' ? '' : 'style="display:none"';

            echo "<div $style><input type='text' name='accessschema_client_key' value='" . esc_attr($val) . "' class='regular-text' /></div>";
        },
        'accessschema-client',
        'accessschema_client_section'
    );
});